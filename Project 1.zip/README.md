Project Library
Este proyecto se hizo con flask un mini framework de python,
esta enfocado a lo web, se uso también html, para la creacion de este.

styles.css
contiene todos los diseños utilizados para este proyecto

en la carpeta template se contienen todos los archivos html
esto es para que flask reconozca los html

book.html este contiene informacion general sobre el libro buscado,
como su isbn, nombre del autor, año de publicacion, y nombre de la obra
tambien las reseñas que los usuarios tengan para el libro seleccionado.

index.html
contiene todos los libros que existen en la pagina
y un input para buscar cualquier libro deseado

layout.html
archivo necesario para que flask reconozca el diseño de css

log_in.html
Archivo para iniciar sesion en la pagina

log_out.html
Archivo para serrar sesion en la pagina, solo sirve para que flask reconozca
la funcion log_out

sign_up
Archivo para registrar un nuevo usuario en la pagina

los requerimientos necesarios para abrir esta pagina es:
flask
SqAlchemy
